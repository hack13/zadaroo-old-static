About these huds...

These are opensource scripts that are written and/or revised by Butch Arnold of the 3rd Rock Grid www.3rdrockgrid.com. He has kindly put these scripts our opensourse to share with the metaverse. 
The textures for these huds was made by me (Linda Kellie Henson). 

I'll try and explain how to use these in a step by step process. 

1. Import the .xml files for the huds to bring them into your grid. Do this by logging into your grid of choice with a viewer that allows .xml imports (I use imprudence viewer) and go to file on the upper menubar of your viewer and choose "Import+Upload" and locate the hud and upload it. 

2. Create the scripts in your inventory by opening the notecards in the file I have supplied and copy and paste them into a script in world. Name them in a way so that you know which script is which. 

3. Put the scripts in the correct places. There is an upper and lower panel for each hud. Put the upper panel script into the contents of the upper panel of the hud using edit linked parts (pay attention and make sure you have the skin one in the skin hud and the nail script in the nail hud). Then put the lower panel scripts into the contents of the lower panels of the huds using edit linked parts. Make sure that the huds have the upper panel as the root/primary prim (will highlight in yellow when in edit mode) and the lower panel is the child prim (will highlight in blue when in edit mode). 

Now the huds are done. Pick them up and take them into your inventory. Right click it and choose "attach hud" and then choose where on your screen you want it to attach. I always pick center and then move it to where I want it on my screen. 


Now you need to make the hud work with the scupty/prim feet. 

In the shoe/foot primary prim put in the scripts for Skin color (SkinColorScript) and Nail color (NailColorScript). These scritps will need to be edited. 

In the skin color script there will be the following that you need to edit...

{ 
            vector color_vector = message;    
            llSetLinkColor(3, color_vector, ALL_SIDES); //the primary prim 
            llSetLinkColor(4, color_vector, ALL_SIDES);
            llSetLinkColor(7, color_vector, ALL_SIDES);
            llSetLinkColor(14, color_vector, ALL_SIDES);
            llSetLinkColor(18, color_vector, ALL_SIDES);
            llSetLinkColor(19, color_vector, ALL_SIDES);                  
            }    

You will need to change the numbers here to match the linkset number of your foot and toes. In this example the foot is number 3 and the toes are numbers 4,7,14,18,19. If you use the imprudence viewer it will show the linkset number just by choosing that prim in edit linked parts and it will show up what link number that part is in your edit window.

And you will do the same for editing the nails script

 { 
            vector color_vector = message;    
            llSetLinkColor(2, color_vector, ALL_SIDES); //the primary prim 
            llSetLinkColor(5, color_vector, ALL_SIDES);
            llSetLinkColor(6, color_vector, ALL_SIDES);
            llSetLinkColor(15, color_vector, ALL_SIDES);
            llSetLinkColor(16, color_vector, ALL_SIDES);
                              
            }       
In this case ther are only 5 numbers because there are 5 toenails. You will need to do this for each foot unless the linkset numbers are the same for both shoes (which probably isn't the case).



This is all very hard for me to explain so if anyone can figure it out and would like to write a tutorial on how to do it I would be gratful and I would be glad to post the link to the tutorial. 